import java.util.ArrayList;
import java.util.List;

public class Shopping {

    interface PaymentProcessor {
        void processPayment(double amount);
    }

    class Product {
        private String productName;
        private ProductDetails productDetails;

        public Product(String productName, String description, double price) {
            this.productName = productName;
            this.productDetails = new ProductDetails(description, price);
        }

        public String getProductName() {
            return productName;
        }

        public ProductDetails getProductDetails() {
            return productDetails;
        }

        class ProductDetails {
            private String description;
            private double price;

            public ProductDetails(String description, double price) {
                this.description = description;
                this.price = price;
            }

            public String getDescription() {
                return description;
            }

            public double getPrice() {
                return price;
            }
        }
    }

    class Electronics extends Product {
        private String brand;

        public Electronics(String productName, String description, double price, String brand) {
            super(productName, description, price);
            this.brand = brand;
        }

        public String getBrand() {
            return brand;
        }
    }

    class Clothing extends Product {
        private String size;

        public Clothing(String productName, String description, double price, String size) {
            super(productName, description, price);
            this.size = size;
        }

        public String getSize() {
            return size;
        }
    }

    class ShoppingCart {
        private List<Product> cartItems = new ArrayList<>();

        public void addProduct(Product product) {
            cartItems.add(product);
            System.out.println(product.getProductName() + " has been added to the cart.");
        }

        public void removeProduct(Product product) {
            if (cartItems.remove(product)) {
                System.out.println(product.getProductName() + " has been removed from the cart.");
            } else {
                System.out.println(product.getProductName() + " is not in the cart.");
            }
        }

        public void displayCart() {
            System.out.println("Items in the cart:");
            for (Product item : cartItems) {
                System.out.println(item.getProductName() + " - " + item.getProductDetails().getDescription() + " - $" + item.getProductDetails().getPrice());
            }
        }
    }

    class PaymentProcessorImpl implements PaymentProcessor {
        @Override
        public void processPayment(double amount) {
            System.out.println("Payment of $" + amount + " processed successfully.");
        }
    }


   
        public static void main(String[] args) {
            Shopping shopping = new Shopping(); 

        Shopping.Product laptop = shopping.new Electronics("Laptop", "High-performance laptop", 1500.0, "XYZ");
        Shopping.Product tShirt = shopping.new Clothing("T-Shirt", "Cotton T-Shirt", 1000.0, "M");

        Shopping.ShoppingCart cart = shopping.new ShoppingCart();
        cart.addProduct(laptop);
        cart.addProduct(tShirt);

        cart.displayCart();

        cart.removeProduct(laptop);
        cart.displayCart();

        PaymentProcessor paymentProcessor = shopping.new PaymentProcessorImpl();
        paymentProcessor.processPayment(1600.0); 
    }
}


